<%@ page import="com.infmglproject.CountGuestsTables" %>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="CSS/user-home.css">
    <script src="https://kit.fontawesome.com/5f69afeadf.js" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Counter-Up/1.0.0/jquery.counterup.min.js"></script>
    <link rel="shortcun icon" type="image/png" href="Images/xylo-logo-favicon.png">
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
</head>
<body>

    <div id="parallax">

    <!-- Navbar -->
    <header>
        <img src="Images/Xylo-logo.png" width="191" class="header-logo">
        <input type="checkbox" id="nav-toggle" class="nav-toggle">
        <nav>
            <ul>
                <li><a href="Home.jsp">Home</a></li>
                <li><a href="About.jsp">About</a></li>
                <li><a href="Contact.jsp">Contact</a></li>
                <li><a href="SignIn.jsp">Create Reservation</a></li>
            </ul>
        </nav>
        <label for="nav-toggle" class="nav-toggle-label">
            <span></span>
        </label>
        <div id="progress-bar"></div>
    </header>

    <div class="block1-wrapper">
        <div class="block1-container">
            <div class="image" data-aos="fade" data-aos-duration="1500">
                <img src="Images/Xylo-logo.png" class="hero-logo">
            </div>
            <div class="image" data-aos="fade" data-aos-duration="3000">
                <img src="Images/home-hero2.jpg" class="hero-image">
            </div>
        </div>
    </div>

    <div class="pseudoblock"></div>

    <!--Block2 - Content-->
    <div class="block2-container">
        <div class="block2-content">
            <h2 class="block2-heading">PARTY AT XYLO</h2>
            <h1>A NIGHT LIKE NO OTHER</h1>
            <p class="block2-body">
                Bringing you a night like no other! Xylo at The Palace is the country's #1 nightclub. And its decks have been graced by some of the globe's
                most celebrated DJs as well as the country's top talents. Ultra VIP bottle service, live performers and state of art lighting and sound bring you a clubbing experience that is at par with the very best in the world.
            </p>
        </div>
    </div>

	   <%//Code to retrieve the current counts from the database%>
	   <% int tablesAvailable = CountGuestsTables.getTablesAvailable(request, response); %>
	   <% int currentGuests = CountGuestsTables.getCurrentGuests(request, response); %>
	   
    <!-- Block 3-->
    <div class="block3-wrapper">
        <div class="wrapper">
            <div class="container" data-aos="zoom-in" data-aos-duration="1000">
                <i class="fas fa-wine-glass"></i>
                <span class="num" data-val="<%= tablesAvailable %>" id="tablesAvailable"><%= tablesAvailable %></span>
                <span class="text">Tables Available</span>
            </div>
            <div class="container" data-aos="zoom-in" data-aos-duration="1500">
                <i class="fa-solid fa-users"></i>                
				<span class="num" data-val="<%= currentGuests %>" id="currentGuests"><%= currentGuests %></span>
                <span class="text">Current Guests</span>
            </div>
            <div class="container" data-aos="zoom-in" data-aos-duration="2000">
                <a href="https://qrco.de/bcckT3">
                    <i class="fas fa-list"></i>
                </a>
                <span class="num" data-val="221">0</span>
                <a href="https://qrco.de/bcckT3">
                    <span class="text-link">Menu Items</span>
                </a>
            </div>
            <div class="container" data-aos="zoom-in" data-aos-duration="2500">
                <i class="fas fa-star"></i>
                <span class="num" data-val="5">0</span>
                <span class="text">Rating</span>
            </div>
        </div>
    </div>

    <!-- Block 4 (Gallery) -->

    <div class="gallery-wrapper" id="b5">
        <h1 class="gallery-heading">THE <span>XYLO</span> EXPERIENCE</h1>
        <div class="gallery-container">
        <div class="gallery-blocks w1 h1" data-aos="fade-up" data-aos-duration="700">
            <div class="gallery-item">
                    <div class="image">
                        <img src="Images/home-img1.jpg" alt="Image 1">
                    </div>
            </div>
        </div>
        <div class="gallery-blocks w2 h2" data-aos="fade-up" data-aos-duration="1000">
            <div class="gallery-item">
                <div class="image">
                    <img src="Images/home-img2.jpg" alt="Image 2">
                </div>
            </div>
        </div>
        <div class="gallery-blocks w3 h3" data-aos="fade-up" data-aos-duration="1300">
            <div class="gallery-item">
                <div class="image">
                    <img src="Images/home-img3.jpg" alt="Image 3">
                </div>
            </div>
        </div>
        <div class="gallery-blocks w4 h4" data-aos="fade-up" data-aos-duration="1600">
            <div class="gallery-item">
                <div class="image">
                    <img src="Images/home-img4.jpg" alt="Image 4">
                </div>
            </div>
        </div>
        <div class="gallery-blocks w5 h5" data-aos="fade-up" data-aos-duration="1000">
            <div class="gallery-item">
                <div class="image">
                    <img src="Images/home-img5.jpg" alt="Image 5">
                </div>
            </div>
        </div>
        <div class="gallery-blocks w6 h6" data-aos="fade-up" data-aos-duration="1300">
            <div class="gallery-item">
                <div class="image">
                    <img src="Images/home-img6.jpg" alt="Image 6">
                </div>
            </div>
        </div>
        <div class="gallery-blocks w7 h7" data-aos="fade-up" data-aos-duration="1300">
            <div class="gallery-item">
                <div class="image">
                    <img src="Images/home-img7.jpg" alt="Image 7">
                </div>
            </div>
        </div>
        <div class="gallery-blocks w8 h8" data-aos="fade-up" data-aos-duration="1000">
            <div class="gallery-item">
                <div class="image">
                    <img src="Images/home-img8.jpg" alt="Image 8">
                </div>
            </div>
        </div>
        <div class="gallery-blocks w9 h9" data-aos="fade-up" data-aos-duration="1300">
            <div class="gallery-item">
                <div class="image">
                    <img src="Images/home-img9.jpg" alt="Image 9">
                </div>
            </div>
        </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <div class="footer-row">
            <div class="footer-col1">
                <img src="Images/Xylo-logo.png" alt="Xylo Logo" class="footer-logo">
                <p>
                    Palace is the greatest place to be. Submerge yourself deep into world-quality clubbing, par with best anywhere
                    &mdash; part of unique international elite clubs with levels of full experiences, everytime.
                </p>
            </div>
            <div class="footer-col">
                <h3 class="footer-title">Links</h3>
                <ul class="footer-links">
                    <li class="footer-links"><a href="Home.jsp" class="footer-links-content">Home</a></li>
                    <li class="footer-links"><a href="About.jsp" class="footer-links-content">About</a></li>
                    <li class="footer-links"><a href="Contact.jsp" class="footer-links-content">Contact</a></li>
                    <li class="footer-links"><a href="SignIn.jsp" class="footer-links-content">Create Reservation</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h3 class="footer-title">Be Updated With Anything Xylo!</h3>

                <form class="form-email" action="https://formsubmit.co/idel.aranilla@gmail.com" method="POST">
                    <i class="fa-solid fa-envelopes-bulk"></i>
                    <input type="hidden" name="_autoresponse" value="Welcome to Xylo. Our Team will contact you shortly. See you soon!">
                    <input type="email" name="email" placeholder="  Enter your email ID" required>
                    <button type="submit"><i class="fa-footer fa-solid fa-arrow-right-from-bracket"></i></button>
                </form>

                <div class="footer-social-icons">
                    <a href="https://www.facebook.com/XYLOatThePalace/" target="_blank">
                        <i class="fa-brands fa-facebook-square"></i>
                    </a>
                    <a href="#">
                        <i class="fa-brands fa-twitter-square"></i>
                    </a>
                    <a href="https://www.instagram.com/xylomanila/?hl=en" target="_blank">
                        <i class="fa-brands fa-instagram-square"></i>
                    </a>
                    <a href="https://www.youtube.com/channel/UCC6grB_kGN2CwyBT9WTXTaA" target="_blank">
                        <i class="fa-brands fa-youtube"></i>
                    </a>
                    <a href="https://www.linkedin.com/company/the-palace-manila/" target="_blank">
                        <i class="fa-brands fa-linkedin"></i>
                    </a>
                </div>
            </div>
        </div>
        <hr>
        <p class="copyright">INF213 Hi-5 - NU-Manila (CTINFMGL) 2023-2024</p>
    </footer>

    <!-- Script -->
    <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
    <script src="JS/home-script.js"></script>
    <script>
        AOS.init();
    </script>
</body>
</html>